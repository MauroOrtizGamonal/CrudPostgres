<?php
echo("Guardando la mascota");
$nombre=$_POST['nombre'];
$edad=$_POST['edad'];
$consulta="insert into mascotas(nombre,edad) values(?,?);";
$conn= new PDO("pgsql:host=localhost;port=5432;dbname=curso","postgres","CURSO");
//var_dump($conn);

$insertar=$conn->prepare($consulta);
$result=$insertar->execute([$nombre,$edad]);
//var_dump($result);
header("Location:index.html");
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body style="text-align: center; background-color: rgb(255, 255, 255);color: rgb(10, 10, 10); font-size: 40px;">
    <h2><marquee>Crud con Postgres</marquee></h2>
    <a href="alta.html" style="text-decoration: none; color: rgb(0, 0, 0);"><marquee direction="right">Nueva mascota</marquee></a>
    <marquee behavior="scroll" direction="left"><img src="https://tecneofito.com/wp-content/uploads/2017/11/fish-swimming.gif" width="188" height="188" alt="Swimming fish" /></marquee>
    <?php
    require_once("conexion.php");
    ?>
</body>

</html>
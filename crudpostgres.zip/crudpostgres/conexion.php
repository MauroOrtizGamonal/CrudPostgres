<?php
$conn = new PDO("pgsql:host=localhost;port=5432;dbname=curso", "postgres", "CURSO");
$resultado=$conn->query("select * from mascotas;");

echo("<table class='arriba'>");
echo("<tr>
        <td>ID</td>
        <td>Nombre</td>
        <td>Edad</td>
    </tr>");

while ($row = $resultado->fetch(PDO::FETCH_ASSOC)) {

echo"<tr class='abajo'>";
        echo"<td>".$row['id']."</td>";
        echo"<td>".$row['nombre']."</td>";
        echo"<td>".$row['edad']."</td>";
    echo"</tr>";
 }//cierra bucle

echo("</table>");